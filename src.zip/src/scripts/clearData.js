 /**  clearDate.js
 * Set the stored data array to null
 */
chrome.storage.local.set({ mouseMovementArray: null });
