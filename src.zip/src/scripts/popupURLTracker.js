
document.getElementById('onButton').onclick = onoff;
document.getElementById('offButton').onclick = off;


var emptyArray = new Array;
function off(){
  alert("Productive mode off.");
  chrome.storage.local.set({unprodArray: emptyArray})
}

function onoff(){
  alert("Productive mode on.");
  chrome.storage.local.get({ua: []}, function(data){

    chrome.storage.local.set({unprodArray: data.ua})
  })
}
