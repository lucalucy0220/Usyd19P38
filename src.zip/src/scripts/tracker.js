<!DOCTYPE html>     
<html>     
<head>     
<script type="text/javascript">
var url=window.location.href;
window.onload=function(){
  var txt=document.getElementsByTagName("input")[0];
  var second=0; 
  var minute=0; 
  var hour=0; 
  function interval(){ 
    second++; 
    if(second==60){ 
      second=0;
      minute+=1; 
    } 
    if(minute==60){ 
      minute=0;
      hour+=1; 
    }
    txt.value=hour+"hour"+minute+"minute"+second+"second"; 
    setTimeout(interval,1000); 
  } 
  interval()
}
document.write(url)
</script>
</head> 
<body> 
<div>you stay for this website for:</div>
<input name="textarea" type="text" value=""/> 
</body> 
</html>