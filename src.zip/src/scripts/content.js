function form(){
  var product = document.getElementById('product').value;
  alert(product);
};