window.onload = displayTable();
function displayTable(){
  chrome.storage.local.get({urlArray:[]}, function(data){

    var table = document.getElementById("ThisTable");
    var row = table.insertRow(-1);

    for(var i=0,length=data.urlArray.length; i<length; i++){
      console.log(data.urlArray);

      var row = table.insertRow(-1);
    
      var url = data.urlArray[i][0]
      row.insertCell(0).innerHTML = url;
      row.insertCell(1).innerHTML = data.urlArray[i][1] + " seconds";
      row.insertCell(2).innerHTML = data.urlArray[i][2];
    }
  })
}
