var temp = new Array;


function getTableElements(){
  var x = document.getElementById("form");
  var url = x.elements[0].value;

  var n = document.getElementById("cat");
  var category = n.options[n.selectedIndex].text;
  updateUA(url, category);


}

function updateUA(url, category){
  if(category === "Unproductive"){
    temp.push(url);

    chrome.storage.local.set({ua: temp})
  }

  //chrome.storage.local.set({unprodArray: temp})

}

function init(){
    document.getElementById('form').onsubmit = getTableElements;

    chrome.storage.local.get({ua: []}, function(data){

      temp = data.ua;

      var table = document.getElementById("unprodTable");

      for(var i=0,length=data.ua.length; i<length; i++){
          var row = table.insertRow(-1);

          row.insertCell(0).innerHTML = data.ua[i];
      }

    })
}
window.onload = init;
